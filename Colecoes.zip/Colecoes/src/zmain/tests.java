package zmain;


/**
 *
 * @author Nome : José Pedro Fernandes Número: 8190239 Turma: 1
 */
public class tests {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
